 //puxei do HTML usando id e associei a variavel par
 const par = document.getElementById('paragrafo');
 //eu troque o atributo title do par
 par.title = 'vc é o meu pato no clash royale'