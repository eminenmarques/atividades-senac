const impar = document.getElementById('aiai');
const legal = document.getElementById('papa');
const par = impar.children;
legal.innerHTML = par.length;

