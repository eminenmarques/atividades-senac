//puxei do HTML usando id e associei a variavel par
const par = document.getElementById('fusca');
//modifiquei usando o atributo src
par.src = "https://carrosp.com.br/img/6/x/volkswagen-fusca-1.3-6209810-41172890.webp";