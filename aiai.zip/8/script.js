// declara uma função
function clickbutton() {
//puxei do HTML usando id e associei a variavel par
const par = document.getElementById('input');
//imprime no console o valor do input
console.log(par.value);
}
