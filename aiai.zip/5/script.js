//declaraa uma função
function camaro () {
//eu selecionei camaro usando id e associei a variavel par
var par = document.getElementById('camaro');
//eu useia para mudar o estilo do elemento par
par.style.background = "yellow";
}