//busquei do html usando id e associei a variavel par
const par= document.getElementById('div');
//eu adicionei a classe c1 ao elemento
par.classList.add('c1')