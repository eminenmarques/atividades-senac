//Este codigo vai renderizar todo o codigo HTML
window.onload = function() {
 //puxei do HTML usando id e associei a variavel par
const par = document.getElementById('aiai');
//vai desabilitar o botão
par.disabled = true;
}
