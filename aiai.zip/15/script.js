 //puxei do HTML usando id e associei a variavel par
const par = document.getElementById('ai');
// foi usado para remover uma classe
par.classList.remove('aiai')