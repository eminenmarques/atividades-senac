//aqui eu usei let para declarar par como uma varaivel usei getElementByID para selecionar o que queria do index
let par = document.getElementById('canetaazul');
//Aqui eu usei par.style.color para mudar a cor da fonte para azul
par.style.color = "blue";