//vai selecionar o elemnto do id "removame" e associar ele a variavel par
const par = document.getElementById('removame');
//ele ira remover o elemento que esta selecionado
document.body.removeChild(par);