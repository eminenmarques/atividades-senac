//aqui eu usei let para declarar par como uma varaivel usei getElementByID para selecionar o que queria do index
let par = document.getElementById('paragrafo');
// aqui eu usei paragrafo por ser o meu id, e innerHTML para cooresponder o conteudo do elemento par
paragrafo.innerHTML = 'olá Mundo!';